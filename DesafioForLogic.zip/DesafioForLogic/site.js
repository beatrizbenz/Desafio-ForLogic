$(document).ready(function(){
    var pessoa = $("input[type=radio][name='pessoa']:checked").val();
    var campoNomeRazao = document.querySelector("#campoNomeRazao");;
    var campoContato = document.querySelector("#campoContato");
    var campoDataCliente = document.querySelector("#dataCliente");
    var tbody = document.querySelector("#tbody");
    var botao = document.querySelector(".botao");
    var id = 0;

    botao.addEventListener('click', function(){
        id += 1;

        trCliente = document.createElement("tr");
        tdNomeRazao = document.createElement("td");
        tdContato = document.createElement("td");
        tdCategoria = document.createElement("td");
        tdAvaliacao = document.createElement("td");
        tdClienteDesde = document.createElement("td");

        tdNomeRazao.textContent = campoNomeRazao

    });
});