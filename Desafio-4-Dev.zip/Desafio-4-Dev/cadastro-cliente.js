// Declaração de variáveis
var campoRF = document.querySelector('#campoRF');
var campoNome = document.querySelector('#campoNome');
var btn_cadastrar = document.querySelector("#btn_cadastrar");
var tbody = document.querySelector("#tbody");
var form = document.querySelector(".cadastro-cliente");
var data = document.querySelector("input[type='date']");
var campoNota = document.querySelector("#campoNota");
var campoMotivo = document.querySelector("#campoMotivo");

function add_cliente() {
    if (valida_campo() == true) {
        var cliente = new Object();

        cliente.RazaoFantasia = campoRF.value;
        cliente.Nome = campoNome.value;
        cliente.Data = data.value;
        cliente.Nota = campoNota.value;
        cliente.Categoria = determina_categoria();
        cliente.Motivo = campoMotivo.value;
        cliente.Avaliacao = 0;

        form.reset();
        return cliente;
    }
    else {
        console.log();
    }

}

function post(cliente) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText);
        }
    }
    xhr.open("POST", "http://desafio4devs.forlogic.net/api/customers/", true);
    xhr.setRequestHeader("Authorization", "desafio-4-dev");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send(JSON.stringify(cliente));
}


function get() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            BDClientes = JSON.parse(xhr.responseText);
            for (id of Object.keys(BDClientes)) {
                renderizar_tabela(id, BDClientes[id]["RazaoFantasia"], BDClientes[id]["Nome"], BDClientes[id]["Data"], BDClientes[id]["Categoria"], BDClientes[id]["Motivo"]);
            }
        }
    }
    xhr.open("GET", "http://desafio4devs.forlogic.net/api/customers", true);
    xhr.setRequestHeader("Authorization", "desafio-4-dev");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send();
}

function renderizar_tabela(id, razaoNome, nome, data, categoria, motivo) {
    var tdID = document.createElement("td");
    var tdRazaoNome = document.createElement("td");
    var tdNome = document.createElement("td");
    var tdData = document.createElement("td");
    var tdCategoria = document.createElement("td");
    var tdMotivo = document.createElement("td");
    var trCliente = document.createElement("tr");

    tdID.innerHTML = id;
    tdRazaoNome.innerHTML = razaoNome;
    tdNome.innerHTML = nome;
    tdData.innerHTML = data;
    tdCategoria.innerHTML = categoria;
    tdMotivo.innerHTML = motivo;

    trCliente.appendChild(tdID);
    trCliente.appendChild(tdRazaoNome);
    trCliente.appendChild(tdNome);
    trCliente.appendChild(tdData);
    trCliente.appendChild(tdCategoria);
    trCliente.appendChild(tdMotivo);

    tbody.appendChild(trCliente);
}

function valida_campo() {
    validacao = false;
    if (campoRF.value == "") {
        alert("Por favor, informe a razão social ou nome fantasia.")
        campoRF.focus();
        validacao = false;
        return validacao;
    }
    if (campoNome.value == "") {
        alert("Por favor, informe o seu nome.")
        campoNome.focus();
        validacao = false;
        return validacao;
    }
    if (data.value == "") {
        alert("Por favor, informe a data em que se tornou cliente.")
        data.focus();
        validacao = false;
        return validacao;
    }
    if (campoNota.value < 0 || campoNota.value > 10) {
        alert("Nota inválida, digite uma nota de 0 a 10.")
        campoNota.focus();
        validacao = false;
        return validacao;
    }
    if (campoNota.value == "") {
        alert("Por favor, responda a pesquisa de satisfação.");
        campoNota.focus();
        validacao = false;
        return validacao;
    }
    if (campoMotivo == "") {
        alert("Por favor, responda a pesquisa de satisfação.");
        data.focus();
        validacao = false;
        return validacao;
    }
    else {
        validacao = true;
        return validacao;
    }
}

function determina_categoria() {
    var categoria;
    if (campoNota.value == 9 || campoNota.value == 10) {
        categoria = "Promotor";
    }
    if (campoNota.value == 7 || campoNota.value == 8) {
        categoria = "Neutro";
    }
    if (campoNota.value >= 0 && campoNota.value <= 6) {
        categoria = "Detrator";
    }
    return categoria;
}

btn_cadastrar.addEventListener("click", function () {
    post(add_cliente());
    setTimeout(function () {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                BDClientes = JSON.parse(xhr.responseText);
                tbody.innerHTML = "";
                for (id of Object.keys(BDClientes)) {
                    renderizar_tabela(id, BDClientes[id]["RazaoFantasia"], BDClientes[id]["Nome"], BDClientes[id]["Data"], BDClientes[id]["Categoria"], BDClientes[id]["Motivo"]);
                }
            }
        }
        xhr.open("GET", "http://desafio4devs.forlogic.net/api/customers", true);
        xhr.setRequestHeader("Authorization", "desafio-4-dev");
        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhr.send();
    }, 2000);
});

get();