var mes = document.querySelector("#mes");
var ano = document.querySelector("#ano");
var tcorpo = document.querySelector("#tcorpo");
var btn_avaliacao = document.querySelector("#btn_avaliacao");
var BDAvaliacao = [];
var BDClientes = [];
var IDAtual;
var participantes = [];
var clientes_validos = [];
var valida;

function get_clientes() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            fireBase = JSON.parse(xhr.responseText);
            for (id of Object.keys(fireBase)) {
                cliente(id, fireBase[id]["RazaoFantasia"], fireBase[id]["Nome"], fireBase[id]["Data"], fireBase[id]["Nota"], fireBase[id]["Categoria"], fireBase[id]["Motivo"], fireBase[id]["Avaliacao"]);
            }
        }
        if (xhr.status === 204) {
            return "";
        }
    }
    xhr.open("GET", "http://desafio4devs.forlogic.net/api/customers", true);
    xhr.setRequestHeader("Authorization", "desafio-4-dev");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send();
}

function cliente(id, razaoFantasia, nome, data, nota, categoria, motivo, avaliacao) {
    var cliente = new Object();

    cliente.ID = id;
    cliente.RazaoFantasia = razaoFantasia;
    cliente.Nome = nome;
    cliente.Data = data;
    cliente.Nota = nota;
    cliente.Categoria = categoria;
    cliente.Motivo = motivo;
    cliente.Avaliacao = avaliacao;

    BDClientes.push(cliente);
}

function renderizar_resultado() {
    if (BDAvaliacao[0]["ID"] == 1 && BDAvaliacao[0]["Resultado"] == 0) {
        tcorpo.innerHTML = "";
    } else {
        tcorpo.innerHTML = "";
        for (i = 0; i < BDAvaliacao.length; i++) {
            var tdmesAno = document.createElement("td");
            var tdResultado = document.createElement("td");
            var tdParticipantes = document.createElement("td");
            var divResultado = document.createElement("div");
            var trResultado = document.createElement("tr");

            tdmesAno.innerHTML = BDAvaliacao[i]["mesAno"];
            tdParticipantes.innerHTML = BDAvaliacao[i]["Participantes"];

            if (BDAvaliacao[i]["Resultado"] >= 80.00) {
                divResultado.classList.add("resultado-verde");
            }
            if (BDAvaliacao[i]["Resultado"] <= 79.99 && BDAvaliacao[1]["Resultado"] >= 60) {
                divResultado.classList.add("resultado-amarelo");
            }
            if (BDAvaliacao[i]["Resultado"] < 60) {
                divResultado.classList.add("resultado-vermelho");
            }

            tdResultado.appendChild(divResultado);
            trResultado.appendChild(tdmesAno);
            trResultado.appendChild(tdResultado);
            trResultado.appendChild(tdParticipantes);
            tcorpo.appendChild(trResultado);
        }
    }
}

function get_avaliacao() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = setTimeout(function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            avaliacao = JSON.parse(xhr.responseText);
            BDAvaliacao = [];
            for (id of Object.keys(avaliacao)) {
                avaliacoes(id, avaliacao[id]["ID"], avaliacao[id]["mesAno"], avaliacao[id]["Resultado"], avaliacao[id]["Participantes"]);
                IDAtual = avaliacao[id]["ID"];
            }
            return IDAtual;
        } if (xhr.status === 204) { post_idAvaliacao(); IDAtual = 1; return IDAtual; }
    }, 1500);
    xhr.open("GET", "http://desafio4devs.forlogic.net/api/evaluations");
    xhr.setRequestHeader("Authorization", "desafio-4-dev");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send();
}

function avaliacoes(IDFirebase, id, mesAno, resultado, participantes) {
    evaluations = new Object();
    evaluations.IDFirebase = IDFirebase;
    evaluations.ID = id;
    evaluations.mesAno = mesAno;
    evaluations.Resultado = resultado;
    evaluations.Participantes = participantes;

    BDAvaliacao.push(evaluations);
}

function put_cliente(IDFirebase, pos, participantes, IDAvaliacao) {
    var cliente = new Object();

    cliente.RazaoFantasia = participantes[pos]["RazaoFantasia"];
    cliente.Nome = participantes[pos]["Nome"];
    cliente.Data = participantes[pos]["Data"];
    cliente.Nota = participantes[pos]["Nota"];
    cliente.Categoria = participantes[pos]["Categoria"];
    cliente.Motivo = participantes[pos]["Motivo"];
    cliente.Avaliacao = IDAvaliacao;

    var json = JSON.stringify(cliente);

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText);
        }
    }
    xhr.open("PUT", "http://desafio4devs.forlogic.net/api/customers/" + IDFirebase + "");
    xhr.setRequestHeader("Authorization", "desafio-4-dev");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send(json)
}


function post_idAvaliacao() {
    var dataID = new Object();
    dataID.IDFirebase = 0;
    dataID.ID = 1;
    dataID.mesAno = 0;
    dataID.Resultado = 0;
    dataID.Participantes = 0;
    var json = JSON.stringify(dataID);

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = setTimeout(function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText);
        }
    }, 1000);
    xhr.open("POST", "http://desafio4devs.forlogic.net/api/evaluations/");
    xhr.setRequestHeader("Authorization", "desafio-4-dev");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send(json);
}


function put_avaliacao(IDFirebase, id, mes, ano, Resultado, Participantes) {
    var evaluation = new Object();

    evaluation.ID = id;
    evaluation.mesAno = mes + " / " + ano;
    evaluation.Resultado = Resultado;
    evaluation.Participantes = Participantes;

    var json = JSON.stringify(evaluation);

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText);
        }
    }
    xhr.open("PUT", "http://desafio4devs.forlogic.net/api/evaluations/" + IDFirebase + "");
    xhr.setRequestHeader("Authorization", "desafio-4-dev");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send(json)
}

function post_avaliacao(id, mes, ano, Resultado, Participantes) {
    var evaluation = new Object();

    evaluation.ID = id;
    evaluation.mesAno = mes + " / " + ano;
    evaluation.Resultado = Resultado;
    evaluation.Participantes = Participantes;

    var json = JSON.stringify(evaluation);

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText);
        }
    }
    xhr.open("POST", "http://desafio4devs.forlogic.net/api/evaluations/");
    xhr.setRequestHeader("Authorization", "desafio-4-dev");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send(json);
}

function gerar_resultado(participantes) {
    qt_participantes = participantes.length == 0 ? 1 : participantes.length;
    detratores = 0;
    promotores = 0;
    for (i = 0; i < qt_participantes; i++) {
        if (participantes[i]["Nota"] == 9 || participantes[i]["Nota"] == 10) {
            promotores += 1;
        }
        if (participantes[i]["Nota"] >= 0 && participantes[i]["Nota"] <= 6) {
            detratores += 1;
        }
    }
    resultado = ((promotores - detratores) / qt_participantes) * 100;
    if (resultado <= 0) {
        resultado = 0;
    }
    return resultado.toFixed(2)
}

function gerar_participantes(BDClientes, IDAtual, clientes_validos) {
    qtde_clientes = BDClientes.length;
    clientes_validos.length = 0;
    for (i = 0; i < qtde_clientes; i++) {
        if ((BDClientes[i]["Avaliacao"]) == 0) {
            clientes_validos.push(BDClientes[i]);
        } else{
            if((BDClientes[i]["Avaliacao"]+1) == IDAtual || (BDClientes[i]["Avaliacao"]+2) == IDAtual){
                console.log("")
            }else{
                clientes_validos.push(BDClientes[i]);
            }
        }
    }
    return clientes_validos;
}

function valida_clientes(clientes_validos, participantes) {
    var qtde_clientes_validos = clientes_validos.length;
    if (qtde_clientes_validos < 5) {
        alert("Número de clientes menor que 5. Por favor, cadastre mais clientes para que seja possível gerar a avaliação com 20% do total.");
    }
    else {
        vinte_porcento = qtde_clientes_validos * 0.2;
        while (Math.trunc(vinte_porcento) != 0) {
            random = Math.floor((Math.random()) * qtde_clientes_validos);
            vinte_porcento -= 1;
            participantes.push(clientes_validos[random]);
        }
        return participantes;
    }
}

function registra_participacao(participantes, IDAtual) {
    for (i = 0; i < participantes.length; i++) {
        put_cliente(participantes[i]["ID"], i, participantes, IDAtual);
    }
}

function valida_mes(BDAvaliacao, mes, ano, valida) {
    mesAno = mes + " / " + ano
    for (i = 0; i < BDAvaliacao.length; i++) {
        if (BDAvaliacao[i]["mesAno"] == mesAno) {
            valida = false;
            return valida;
        }
    }
}

function contaID(BDAvaliacao, IDAtual){
    for (i = 0; i < BDAvaliacao.length; i++) {
        if (BDAvaliacao[0]["mesAno"] == 0 && BDAvaliacao.length == 1) {
            return IDAtual = 1;
        } else {
            IDAtual += 1;
            return IDAtual;
        }
    }
}

btn_avaliacao.addEventListener('click', function () {
    get_avaliacao();
    setTimeout(5000);
    setTimeout(function () {
        gerar_participantes(BDClientes, contaID(BDAvaliacao, IDAtual), clientes_validos);
        console.log(clientes_validos)
        valida_clientes(clientes_validos, participantes, valida);
        if(valida_mes(BDAvaliacao, mes.value, ano.value, valida) == false){
            alert("No mês escolhido, já foi feita uma avaliação!");
        }else{
            registra_participacao(participantes, contaID(BDAvaliacao, IDAtual));
            resultado = gerar_resultado(participantes);
            nomes_participantes = "";
            qt_participantes = participantes.length;
            for (i = 0; i < qt_participantes; i++) {
                nomes_participantes += "|" + participantes[i]["Nome"] + "|";
            }
            if (contaID(BDAvaliacao, IDAtual) == 1) {
                put_avaliacao(BDAvaliacao[0]["IDFirebase"], 1, mes.value, ano.value, resultado, nomes_participantes);
            } else {
                post_avaliacao(contaID(BDAvaliacao, IDAtual), mes.value, ano.value, resultado, nomes_participantes);
            }
        }
    }, 1500);
    setTimeout(function () {
        location.reload();
        setTimeout("renderizar_resultado()", 3000);
    }, 5000);
});

get_avaliacao();
get_clientes();
setTimeout("renderizar_resultado()", 1500);



